import { fireEvent, render, screen } from "@testing-library/react"
import Home from "../Components/Home"
import { BrowserRouter } from "react-router-dom"
import '@testing-library/jest-dom';
import userEvent from "@testing-library/user-event";
import axios from "axios"
import { act } from "react-dom/test-utils";

jest.mock("axios")

afterEach(() => {
    jest.restoreAllMocks()
})


test("Test for Home", async () => {
    render(<BrowserRouter><Home /></BrowserRouter>)

    const allbutton = await screen.findAllByRole("button")
    expect(allbutton).toHaveLength(2)

    //Test for input
    const inputbar = screen.getByTestId("id-input")
    userEvent.type(inputbar, "212");
    expect(inputbar.value).not.toMatch(/\D/) //should be only a number

    //Submit button should be disable if not a number
    expect(allbutton[0]).not.toBeDisabled()

    //error msg to be displayed for worng input value
    userEvent.clear(inputbar)
    userEvent.type(inputbar, "addsa")  //for text this condition will be passed
    const Error = await screen.findByText("Please enter only numbers")
    expect(Error).toBeInTheDocument()

})

test("Api testing", async () => {
    //Button tetsing and Api testing

    await act(async () => { render(<BrowserRouter><Home /></BrowserRouter>) });

    const inputbar = screen.getByTestId("id-input")
    const allbutton = await screen.findAllByRole("button")
    userEvent.clear(inputbar)
    userEvent.type(inputbar, "12121")
    fireEvent.click(allbutton[0])

})

test("Api testing random func", async () => {


    await act(async () => { render(<BrowserRouter><Home /></BrowserRouter>) });
    const allbutton = await screen.findAllByRole("button")
    fireEvent.click(allbutton[1])

})

test("Api error testing", async () => {
    const log = jest.spyOn(console, "log")
    const err = new Error("Error")
    axios.get.mockRejectedValue(err)
    await act(async () => { render(<BrowserRouter><Home /></BrowserRouter>) });
    const allbutton = await screen.findAllByRole("button")
    const inputbar = screen.getByTestId("id-input")
    userEvent.clear(inputbar)
    userEvent.type(inputbar, "12121")
    await act(async () => {
        fireEvent.click(allbutton[0])
    })
    expect(log).toBeCalledWith(err)
})

test("Api error testing", async () => {
    const log = jest.spyOn(console, "log")
    const err = new Error("Error")
    axios.get.mockRejectedValue(err)
    await act(async () => { render(<BrowserRouter><Home /></BrowserRouter>) });

    const allbutton = await screen.findAllByRole("button")
    const inputbar = screen.getByTestId("id-input")
    userEvent.clear(inputbar)
    userEvent.type(inputbar, "12121")
    await act(async () => {
        fireEvent.click(allbutton[1])

    })
    expect(log).toBeCalledWith(err)

})




