import {screen,render} from "@testing-library/react"
import { BrowserRouter } from "react-router-dom"
import Asteroids from "../Components/Asteroids"

test("Testing asteroid component",async()=>{
    render(<BrowserRouter><Asteroids/></BrowserRouter>)
    screen.debug()
})