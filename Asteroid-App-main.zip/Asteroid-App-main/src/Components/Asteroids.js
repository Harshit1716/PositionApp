import React, { Component } from 'react'
import "./Asteroids.css"
import { useLocation } from 'react-router-dom'

export class Asteroids extends Component {

    constructor(props){
        super(props);
        this.state={
            data:this.props.location.state
        }
    }

    render() {
        return (
            <div className='asteroid-main'>
                <h1>Asteroid Details</h1>
                {this.state.data?<>
                    <div>ID: {this.state.data.id}</div>
                    <div>Name: {this.state.data.name}</div>
                    <div>Absolute Magnitude: {this.state.data.absolute_magnitude_h}</div>
                    <div>NASA Jpl Url: <a href={this.state.data.nasa_jpl_url} target={"_blank"} rel={"noreferrer noopener"}>{this.state.data.nasa_jpl_url}</a></div>
                </>:<div>No Asteroid found</div>}
            </div>
        )
    }
}


export default function Astero() {
    const location = useLocation();
    return <Asteroids location={location} />;
}