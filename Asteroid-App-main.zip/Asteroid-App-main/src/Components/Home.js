import axios from 'axios'
import React, { Component } from 'react'
import { useNavigate } from 'react-router-dom'
import "./Home.css"
import { ClipLoader } from "react-spinners"

export class Home extends Component {

  constructor(props) {
    super(props);
    this.state = {
      id: "",
      loading: false
    }
  }


  submitFunc = (e) => {
    this.setState({ loading: true })
    e.preventDefault()
    axios.get(`https://api.nasa.gov/neo/rest/v1/neo/${this.state.id}?api_key=${process.env.REACT_APP_API}`)
      .then(
        (res) => {
          this.props.navigate(`/asteroid`, { state: res.data })
        },
        (error) => {
          this.setState({ loading: false })
          console.log(error)
        }
      )
  }

  randomFunc = () => {
    this.setState({ loading: true })
    axios.get(`https://api.nasa.gov/neo/rest/v1/neo/browse?api_key=${process.env.REACT_APP_API}`)
      .then(
        (res) => {
          const randomindex = Math.round(Math.random() * res.data.near_earth_objects.length)
          this.props.navigate(`/asteroid`, { state: res.data.near_earth_objects[randomindex] })
        },
        (error) => {
          this.setState({ loading: false })
          console.log(error)
        }
      )
  }

  render() {
    const { id } = this.state
    return (
      <>
        {this.state.loading ? <div style={{ "textAlign": "center", "paddingTop": "200px" }}><ClipLoader size={100} className='loader' color="black" /></div>
          : <div>
            <div style={{ "textAlign": "center", "fontSize": "4rem", "fontWeight": "bold" }}>Asteroid App</div>
            <form className='form' onSubmit={this.submitFunc}>
              <input data-testid="id-input" value={id} onChange={e => this.setState({ id: e.target.value })} type={"text"} placeholder="Enter the Asteroid Id" />
              {id.match(/\D/) && <div className='error'>Please enter only numbers</div>}
              <button type={"submit"} disabled={!id.trim() || id.match('[^0-9]')}>Submit</button>
              <button type='button' onClick={this.randomFunc}>Random Asteroid</button>
            </form>
          </div>}
      </>
    )
  }
}

export default function Homee() {
  const navigate = useNavigate();

  return <Home navigate={navigate} />;
}
