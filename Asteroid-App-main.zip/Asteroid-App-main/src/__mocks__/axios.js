const mockresponse = {
    data:{
        near_earth_objects:[
            {
                id:21221,
                name:"Arman Kazi",
                absolute_magnitude_h:"abc",
                nasa_jpl_url:"abc.com",
            },
            {
                id:21221,
                name:"Arman Kazi",
                absolute_magnitude_h:"abc",
                nasa_jpl_url:"abc.com",
            }
        ]
    }
}

export default {
    get: jest.fn().mockResolvedValue(mockresponse)
}