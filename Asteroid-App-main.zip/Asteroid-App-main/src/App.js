import React from "react";
import "./app.css"
import Home from "./Components/Home";
import {BrowserRouter,Route,Routes} from "react-router-dom"
import Asteroids from "./Components/Asteroids";

class App extends React.Component {
  render(){
    return (
      <>
       <BrowserRouter>
       <Routes>
        <Route path="/asteroid" element={<Asteroids/>}/>
        <Route path="*" element={<Home/>}/>
       </Routes>
       </BrowserRouter>
      </>
    );
  }
  
}

export default App;
